const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Database Initialization (evoting.db)
const db = new sqlite3.Database('./evoting.db', (err) => {
    if (err) {
        console.error('Error connecting to SQLite database:', err.message);
    } else {
        console.log('Connected to SQLite database (evoting.db)');
    }
});

// Setup Database Schema
db.serialize(() => {
    // 1. Candidates Table
    db.run(`CREATE TABLE IF NOT EXISTS candidates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        position TEXT NOT NULL,
        class_name TEXT NOT NULL,
        manifesto TEXT
    )`);

    // Ensure 'class_name' column exists if upgrading an existing DB
    db.run(`ALTER TABLE candidates ADD COLUMN class_name TEXT DEFAULT ''`, (err) => {
        // Ignores error if column already exists
    });

    // 2. Single-use QR Tokens Table ("Burn-on-use")
    db.run(`CREATE TABLE IF NOT EXISTS tokens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        token TEXT UNIQUE NOT NULL,
        is_used INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // 3. Decoupled Anonymous Votes Table
    db.run(`CREATE TABLE IF NOT EXISTS votes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        candidate_id INTEGER NOT NULL,
        voted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (candidate_id) REFERENCES candidates(id)
    )`);

    // 4. Admin Users Table
    db.run(`CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        two_factor_code TEXT NOT NULL
    )`);

    // Ensure 'two_factor_code' column exists
    db.run(`ALTER TABLE admins ADD COLUMN two_factor_code TEXT DEFAULT '123456'`, (err) => {
        // Ignores error if column already exists
    });

    // Reset and Seed ONLY the official 'teacher' account
    db.run(`DELETE FROM admins`, () => {
        const passwordHash = bcrypt.hashSync('teacher123', 10);
        db.run(
            `INSERT INTO admins (username, password_hash, two_factor_code) VALUES (?, ?, ?)`,
            ['teacher', passwordHash, '123456']
        );
        console.log('--- Admin Account Seeded ---');
        console.log(' Username: teacher');
        console.log(' Password: teacher123');
        console.log(' 2FA Code: 123456');
        console.log('----------------------------');
    });
});

// ==========================================
// 1. PUBLIC CANDIDATE & BALLOT ROUTES
// ==========================================

// Fetch all registered candidates
app.get('/api/candidates', (req, res) => {
    db.all(`SELECT id, name, position, class_name, manifesto FROM candidates`, [], (err, rows) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(rows);
    });
});

// Validate single-use QR token
app.post('/api/vote/validate-token', (req, res) => {
    const { token } = req.body;

    if (!token) {
        return res.status(400).json({ valid: false, message: "Token is required." });
    }

    db.get(`SELECT * FROM tokens WHERE token = ?`, [token], (err, row) => {
        if (err) {
            return res.status(500).json({ valid: false, message: "Database error." });
        }
        if (!row) {
            return res.status(404).json({ valid: false, message: "Invalid QR Token." });
        }
        if (row.is_used === 1) {
            return res.status(403).json({ valid: false, message: "This QR Token has already been used to vote." });
        }

        res.json({ valid: true, message: "Token is valid." });
    });
});

// Submit anonymous vote and "burn" the token
app.post('/api/vote/submit', (req, res) => {
    const { token, candidate_id } = req.body;

    if (!token || !candidate_id) {
        return res.status(400).json({ success: false, message: "Token and candidate selection are required." });
    }

    // Verify token validity first
    db.get(`SELECT * FROM tokens WHERE token = ? AND is_used = 0`, [token], (err, tokenRow) => {
        if (err || !tokenRow) {
            return res.status(400).json({ success: false, message: "Invalid or already consumed QR Token." });
        }

        // Verify candidate exists
        db.get(`SELECT id FROM candidates WHERE id = ?`, [candidate_id], (err, candRow) => {
            if (err || !candRow) {
                return res.status(400).json({ success: false, message: "Invalid candidate selected." });
            }

            // Perform transactional database write
            db.serialize(() => {
                // 1. Record the anonymous vote
                db.run(`INSERT INTO votes (candidate_id) VALUES (?)`, [candidate_id]);

                // 2. Mark (Burn) the QR Token so it cannot be reused
                db.run(`UPDATE tokens SET is_used = 1 WHERE token = ?`, [token], (updateErr) => {
                    if (updateErr) {
                        return res.status(500).json({ success: false, message: "Error completing ballot transaction." });
                    }
                    res.json({ success: true, message: "Thank you! Your vote has been recorded securely." });
                });
            });
        });
    });
});

// ==========================================
// 2. TEACHER / ADMIN PANEL ROUTES
// ==========================================

// Admin Login (Strict Username, Password, and 2FA Code Check)
app.post('/api/admin/login', (req, res) => {
    const { username, password, twoFactorCode } = req.body;

    if (!username || !password || !twoFactorCode) {
        return res.status(400).json({ success: false, message: "Username, password, and 2FA code are required." });
    }

    // Fetch admin user record by exact username
    db.get(`SELECT * FROM admins WHERE username = ?`, [username], (err, admin) => {
        if (err) {
            return res.status(500).json({ success: false, message: "Database error during login." });
        }

        if (!admin) {
            return res.status(401).json({ success: false, message: "Invalid administrative credentials." });
        }

        // 1. Verify Password Hash
        const passwordMatch = bcrypt.compareSync(password, admin.password_hash);
        if (!passwordMatch) {
            return res.status(401).json({ success: false, message: "Invalid administrative credentials." });
        }

        // 2. Verify Account-Specific 2FA Code
        if (admin.two_factor_code !== twoFactorCode) {
            return res.status(401).json({ success: false, message: "Invalid 2FA code for this account." });
        }

        // Verification Passed
        res.json({ success: true, message: "Authenticated successfully with account-tied 2FA." });
    });
});

// Add a new Candidate
app.post('/api/admin/candidates', (req, res) => {
    const { name, position, class_name, manifesto } = req.body;

    if (!name || !position || !class_name) {
        return res.status(400).json({ success: false, error: "Name, position, and class name are required." });
    }

    db.run(
        `INSERT INTO candidates (name, position, class_name, manifesto) VALUES (?, ?, ?, ?)`,
        [name, position, class_name, manifesto || ''],
        function (err) {
            if (err) {
                return res.status(500).json({ success: false, error: err.message });
            }
            res.json({ success: true, candidate_id: this.lastID });
        }
    );
});

// Delete a Candidate
app.delete('/api/admin/candidates/:id', (req, res) => {
    const candidateId = req.params.id;

    db.run(`DELETE FROM candidates WHERE id = ?`, [candidateId], function (err) {
        if (err) {
            return res.status(500).json({ success: false, error: err.message });
        }
        res.json({ success: true, deleted: this.changes });
    });
});

// Generate batch of single-use QR tokens
app.post('/api/admin/generate-tokens', (req, res) => {
    const count = req.body.count || 5;
    const generatedTokens = [];

    db.serialize(() => {
        const stmt = db.prepare(`INSERT INTO tokens (token) VALUES (?)`);
        for (let i = 0; i < count; i++) {
            // Generate a random 8-character unique alphanumeric token
            const token = 'TOKEN-' + crypto.randomBytes(4).toString('hex').toUpperCase();
            stmt.run(token);
            generatedTokens.push(token);
        }
        stmt.finalize((err) => {
            if (err) {
                return res.status(500).json({ success: false, error: err.message });
            }
            res.json({ success: true, tokens: generatedTokens });
        });
    });
});

// Fetch Real-time Vote Results Tally
app.get('/api/admin/results', (req, res) => {
    const query = `
        SELECT c.id, c.name, c.position, c.class_name, COUNT(v.id) AS total_votes
        FROM candidates c
        LEFT JOIN votes v ON c.id = v.candidate_id
        GROUP BY c.id
        ORDER BY total_votes DESC
    `;

    db.all(query, [], (err, rows) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(rows);
    });
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server running smoothly on http://localhost:${PORT}`);
});